// ChartComponent.tsx
import Highcharts, { setOptions } from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import styles from './Crossplot.css'
function useContainerSize(ref) {
    const [size, setSize] = useState({ width: 400, height: 400 });


    useLayoutEffect(() => {
        if (!ref.current) return;
        const observer = new ResizeObserver(([entry]) => {
            const { width, height } = entry.contentRect;
            setSize({ width, height });
        });
        observer.observe(ref.current);
        return () => observer.disconnect();
    }, [ref]);

    return size;
}
export default function IsipVsTopGraphDots({ data, isOpen, well, config }) {
    const containerRef = useRef(null);
    const { width, height } = useContainerSize(containerRef);

    const defaultOptions = ({yTitle}) => ({
        chart: {
            zoomType: 'xy',
            type: 'scatter',
            width: (width - (Number(isOpen) * 50)),
            height,
            backgroundColor: 'var(--palette-background-b-4)',
            plotBackgroundColor: 'var(--palette-background-b-3)',
            marginLeft: 70,
            marginRight: 50,
            marginBottom: 100,
            spacing: [10, 10, 10, 10],
            resetZoomButton: {
                position: { align: 'right', verticalAlign: 'top', x: 0, y: 0 }
            }
        },
        xAxis: {
            title: {
                text: 'Tope <span style="color: #B0B0B0">(m)</span>',
                style: { color: 'var(--palette-primary-text-1)' }, // branco
                useHTML: true
            },
            labels: {
                style: { color: 'var(--palette-primary-text-7)' } // cinza
            },
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: { style: { color: 'var(--palette-primary-text-7)' } },
            tickLength: 0,
            gridLineWidth: 1
        },
        yAxis: {
            title: {
                text: `${yTitle||"ISIP Post"} <span style="color: #B0B0B0">(psi)</span>`,
                style: { color: 'var(--palette-primary-text-1)' } // branco
            },
            labels: {
                style: { color: 'var(--palette-primary-text-7)' } // cinza
            },
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: { style: { color: 'var(--palette-primary-text-7)' } },
            gridLineWidth: 1
        },
        legend: {
            itemStyle: { color: 'var(--palette-primary-text-7)' }
        },
        tooltip: {
            formatter: function () {
                return `
                    <b>${this.series.name}</b><br/>
                    Stage Number: ${this?.point?.stage_number}<br/>
                    Y: ${this.y.toFixed(1)}<br/>
                    X: ${this.x.toFixed(1)}
                `;
            }
        },
        plotOptions: {
            scatter: {
                tooltip: {
                    pointFormat: 'ISIP POST (psi/ft): {point.x}, ISIP PRE (psi/ft): {point.y}'
                }
            }
        },
        title: { text: null },
        credits: { enabled: false },

    });

    const [options, setOptions] = useState(defaultOptions({yTitle: ""}))
    const titleOptions = {
        'isip_pre': 'ISIP PreFrac',
        'isip_post': 'ISIP Post'
    }
    useEffect(() => {
        const dataType = config?.dataType;
        if (data) {
            const series = []
            data?.map((item) => {
                const dataSeries = []
                Object.values(item?.stages)?.map(({ [dataType]: value, top_perforation, stage_number }) => {
                    if (value != undefined != undefined && top_perforation != undefined) {
                        const top_perforation_m = top_perforation / 3.28084
                        dataSeries.push({ y: value, x: top_perforation_m, stage_number })
                    }
                })
                series.push({
                    type: 'scatter',
                    name: item.well.name,
                    data: dataSeries
                })
            })


            setOptions({ ...defaultOptions({yTitle: titleOptions[dataType]}), series })
        }
    }, [data, isOpen, width, height, isOpen, well, config])


    return (
        <div ref={containerRef} className={styles.Crossplot}>
            <HighchartsReact highcharts={Highcharts} options={options} />
        </div>)
}
