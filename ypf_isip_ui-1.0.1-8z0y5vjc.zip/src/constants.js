export const DEFAULT_SETTINGS = {
  isExampleCheckboxChecked: false,
};

export const DATASETS = {
  
}
