import { AppContainer, AppHeader } from '@corva/ui/componentsV2';
import { useAppCommons } from '@corva/ui/effects';

import { DEFAULT_SETTINGS } from './constants';
import logo from './assets/logo.svg';

import styles from './App.css';
import Crossplot from './section/Corssplot';
import useGetData from './effects/useGetData';
import { getFracFleets, getPads, getPadWells } from '@corva/ui/clients/jsonApi';
import { useEffect, useState } from 'react';
import { useWellSummaryData } from '@corva/ui/components/WellSummary';
import useWellsData from './effects/useWellsData';

/**
 * @param {Object} props
 * @param {boolean} props.isExampleCheckboxChecked
 * @param {Object} props.fracFleet
 * @param {Object} props.well
 * @param {Object[]} props.wells
 * @returns
 */
function App({ padId }, ...props) {
  const { appKey } = useAppCommons();
  // NOTE: On general type dashboard app receives wells array
  // on asset type dashboard app receives well object
  const [source, setSource] = useState("corva")
  const [wellList, setWellList] = useState(undefined)
  const [cpData, setCpData] = useState([])

  const predictionStd = {
    stage_number: "stage_number",
    isip_post: "data.ave_isip",
    tvd: "data.mid_tvd"
  }

  const actualStagesStd = {
    stage_number: "data.stage_number",
    isip_post: "data.end_isip",
  }

  const ypfIsipStd = {
    stage_number: "stage_number",
    isip_pre: "data.isip_pre"
  }

  const datasetList = [
    { dataset: "corva#completion.data.actual-stages", query: {}, result: actualStagesStd },
    { dataset: "corva#completion.predictions", query: {}, result: predictionStd },
    { dataset: "ypf#isip_ypf", query: {}, result: ypfIsipStd }]

  const { loading, wellsData } = useWellsData({ wellList: wellList, datasetList: datasetList })

  useEffect(() => {
    const option = {
      app_key: "ypf.dc_completion_metrics.ui",
      fields: "all"
    }
    getPadWells(padId, option).then(response => {
      setWellList(response.data)
    })
  }, [])

  function getValueFromPath(obj, path) {
    if (path.includes(".")) {
      return path.split('.').reduce((acc, key) => acc?.[key], obj);
    } else {
      return obj[path]
    }
  }
  
  function readyForRender(wList, dList, data) {
    let ready = Object.keys(wList).length == Object.keys(data).length
    if (ready) {
      Object.keys(data).map((param) => {
        if (Object.keys(data[param]).length != dList.length) {
          ready = false
        }
      })
    }
    return ready
  }
  useEffect(() => {
    if (wellsData && readyForRender(wellList, datasetList, wellsData)) {

      const newCpData = [];

      Object.keys(wellsData).forEach((well) => {
        const stages = {};

        datasetList.forEach(({ dataset, result }) => {
          if (dataset == "corva#completion.data.actual-stages" && source == "corva") return;
          if (dataset == "corva#completion.predictions" && source != "corva") return;
          const data = wellsData[well][dataset];
          if (!data) return;

          data.forEach((item) => {
            // Extraímos o stage_number conforme o padrão
            const stageNumberPath = result.stage_number;
            const stageNumber = getValueFromPath(item, stageNumberPath);

            if (!stageNumber) return;

            // Inicializa se necessário
            if (!stages[stageNumber]) stages[stageNumber] = {};

            // Identifica a chave do tipo (actual, prediction, ypf) baseado no dataset
            const datasetKey = dataset.includes("actual-stages")
              ? "actual"
              : dataset.includes("predictions")
                ? "prediction"
                : "ypf";
            // Cria um objeto apenas com os dados transformados conforme o resultado padrão
            const parsed = {};
            for (const [key, path] of Object.entries(result)) {
              parsed[key] = getValueFromPath(item, path);
            }
            if ((stages?.[stageNumber] != undefined) || stages?.[stageNumber]?.stage_number == parsed.stage_number) {
              stages[stageNumber] = { ...stages?.[stageNumber], ...parsed };
            } else {
              console.log("stages_numbers doesn't match")
            }
          });
        });
        const wellInfo = wellList.find((w) => w.attributes.asset_id == well)
        newCpData.push({ well: { name: wellInfo?.attributes?.name, asset_id: wellInfo?.attributes?.asset_id }, stages });
      });
      setCpData(newCpData)
      // Aqui você pode usar setState ou fazer algo com newCpData
    }
  }, [wellsData]);
  return (
    <AppContainer header={<AppHeader />} testId={appKey}>
      <div className={styles.container}>
        <Crossplot data={cpData} />
      </div>
    </AppContainer>
  );
}

// Important: Do not change root component default export (App.js). Use it as container
//  for your App. It's required to make build and zip scripts work as expected;
export default App;
