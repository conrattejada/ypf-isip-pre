import { useState, useEffect } from 'react';
import { corvaDataAPI, socketClient } from '@corva/ui/clients';

import { DATASETS } from '../constants';


async function fetchData({ assetId, dataset, query = {}, fields = [] }) {

    const [provider, collection] = dataset.split("#")
    
    try {
        return await corvaDataAPI.get(`/api/v1/data/${provider}/${collection}/`, {
            limit: 1000,
            skip: 0, // NOTE: Required for pagination
            // NOTE: Make sure the sort field hit database indexes. Otherwise the request will take too long
            sort: JSON.stringify({ timestamp: -1 }),
            query: JSON.stringify({ asset_id: assetId, company_id: 375, ...query }),
            // NOTE: To make efficient request - fetch only fields used by the app
            fields: fields.join(','),
        });
    } catch (e) {
        return [];
    }
}

export default function useGetData({ assetId, dataset, query }) {
    const [data, setData] = useState(undefined);
    const [loading, setLoading] = useState(false);
    useEffect(() => {
        
        if (!loading) {
            let unsubscribe;
            const [provider, collection] = dataset.split("#")
            if (assetId) {
                const onDataReceive = event => setData(prevData => prevData.concat(event.data));

                unsubscribe = socketClient.subscribe(
                    { provider: provider, dataset: collection, assetId: assetId },
                    { onDataReceive }
                );
            }

            return () => {
                if (unsubscribe) {
                    unsubscribe();
                }
            };
        } else {
            fetchData({ assetId: assetId, dataset, query })
            .then(response => {
                setData(response);
            })
            .finally(() => setLoading(false));

        }
    }, [loading]);

    useEffect(()=>{
            setLoading(true)
    },[assetId, dataset, query])

    return { loading, data };

}