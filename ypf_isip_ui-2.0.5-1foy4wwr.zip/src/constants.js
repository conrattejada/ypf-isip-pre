export const DEFAULT_SETTINGS = {
  isExampleCheckboxChecked: false,
  graph: "Crossplot", 
  dataType: "isip_post",
  stages: [],
  stageMode: "all",
  source: "Corva",
  padSelected: {mode: "pad"},
};

export const DATASETS = {

}
