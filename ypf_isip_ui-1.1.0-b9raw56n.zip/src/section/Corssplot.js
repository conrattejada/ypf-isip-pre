import HighchartsReact from "highcharts-react-official";
import Highcharts from 'highcharts';
import { use, useEffect, useRef, useState } from 'react';

export default function Crossplot({ data }) {
    const [size, setSize] = useState(undefined)
    const [options, setOptions] = useState(undefined)
    const [series, setSeries] = useState([])
    const max = 4
    const chartRef = useRef(null);

    const handleOptions = () => ({
        chart: {
            zoomType: 'xy',
            resetZoomButton: {
                position: {
                    align: 'right', // ou 'left'
                    verticalAlign: 'top', // ou 'middle', 'bottom'
                    x: 0,
                    y: 0
                }
            },
            type: 'scatter',
            backgroundColor: 'var(--palette-background-b-4)',
            plotBackgroundColor: 'var(--palette-background-b-3)',
            style: {
                aspectRatio: '1 / 1'
            },
            ...size,
            events: {
                load: function () {
                    const chart = this;

                    const plotWidth = chart.plotWidth;
                    const plotHeight = chart.plotHeight;

                    const size = Math.min(plotWidth, plotHeight);

                    chart.setSize(size + chart.plotLeft * 2, size + chart.plotTop * 2, false);
                }
            }
        },
        xAxis: {
            title: {
                text: 'ISIP PRE (psi/ft)',
                style: { color: 'var(--palette-primary-text-7)' }
            },
            gridLineWidth: 1,
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: { style: { color: 'var(--palette-primary-text-7)' } },
            tickLength: 0,
            min: 0,
            gridLineWidth: 1,
            max: max,
            tickInterval: max / 5,
            gridLineWidth: 1,
        },
        yAxis: {
            title: {
                text: 'ISIP POST (psi/ft)',
                style: {
                    color: 'var(--palette-primary-text-7)',
                },
            },
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: {
                style: {
                    color: 'var(--palette-primary-text-7)',
                },
            },
            gridLines: true,
            min: 0,
            gridLineWidth: 1,
            max: max,
            tickInterval: max / 5,
            gridLineWidth: 1,
        },
        legend: {
            itemStyle: {
                color: 'var(--palette-primary-text-7)',
            },
        },
        plotOptions: {
            scatter: {
                tooltip: {
                    pointFormat: 'X: {point.x}, Y: {point.y}',
                },
            },
        },
        tooltip: {
            formatter: function () {
                // Acessa o valor alternativo no ponto
                return `
                <b>Well: ${this.series.name}</b><br/>
                Stage Number: ${this?.point?.stage_number}<br/>
                x: ${this.x}<br/>
                y: ${this.y}
              `;
            },
        },
        series: series,
        credits: {
            enabled: false
        }
    }
    );

    const scale = 0.9

    useEffect(() => {
        if (!chartRef.current) {
            return;
        }

        const resizeObserver = new ResizeObserver((entries) => {
            for (let entry of entries) {
                if (entry.contentRect.width > entry.contentRect.height) {
                    setSize({
                        width: Math.floor(entry.contentRect.height * scale),
                        height: Math.floor(entry.contentRect.height * scale)
                    });
                } else {
                    setSize({
                        width: Math.floor(entry.contentRect.width * scale),
                        height: Math.floor(entry.contentRect.width * scale)
                    });
                }
            }
        });

        resizeObserver.observe(chartRef.current);

        return () => {
            resizeObserver.disconnect();
        };
    }, []);
    const serieMock = [
        {
            symbol: 'square',
            radius: 4,
            fillColor: '#6464FF80',
            lineColor: '#6464FF',
            lineWidth: 1,
        },
        {
            symbol: 'triangle',
            radius: 4,
            fillColor: '#FFCC0080',
            lineColor: '#FFCC00',
            lineWidth: 1,
        },
        {
            symbol: 'circle',
            radius: 4,
            fillColor: '#00CC6680',
            lineColor: '#00CC66',
            lineWidth: 1,
        },
        {
            symbol: 'diamond',
            radius: 4,
            fillColor: '#FF668080',
            lineColor: '#FF6680',
            lineWidth: 1,
        },
        {
            symbol: 'triangle-down',
            radius: 4,
            fillColor: '#FF990080',
            lineColor: '#FF9900',
            lineWidth: 1,
        },
        {
            symbol: 'triangle-left',
            radius: 4,
            fillColor: '#0099FF80',
            lineColor: '#0099FF',
            lineWidth: 1,
        },
        {
            symbol: 'triangle-right',
            radius: 4,
            fillColor: '#9900FF80',
            lineColor: '#9900FF',
            lineWidth: 1,
        },
        {
            symbol: 'rect',
            radius: 4,
            fillColor: '#00CCCC80',
            lineColor: '#00CCCC',
            lineWidth: 1,
        },
    ];



    useEffect(() => {
        if (data?.length > 0) {
            let maxAux = 0;

            const seriesBuild = data.map((serie, key) => {
                const serieData = Object.keys(serie.stages).map((stg) => {
                    const d = serie.stages[stg];
                    const y = d.isip_post / d.tvd;
                    const x = d.isip_pre / d.tvd;

                    if (!Number.isNaN(x) && !Number.isNaN(y)) {
                        const newValue = Math.max(maxAux, x, y);
                        maxAux = newValue;
                        return { x: Number(x?.toFixed(3)), y: Number(y?.toFixed(3)), stage_number: d?.stage_number };
                    } else {
                        return { x: undefined, y: undefined, stage_number: undefined }
                    }
                });

                return {
                    name: serie.well.name,
                    data: serieData.filter((item) => item?.x != undefined && item?.y != undefined && item?.stage_number != undefined),
                    enabled: true,
                    marker: serieMock[key],
                };
            });

            const rest = Math.floor(maxAux) - maxAux
            if (rest + 2 > 5) {
                maxAux = Math.floor(maxAux) + 1
            } else {
                maxAux = Math.floor(maxAux) + 0.5
            }

            setSeries([...seriesBuild, {
                name: '45º',
                type: 'line',
                color: 'red',
                dashStyle: 'Dash',
                marker: { enabled: false },
                enableMouseTracking: false,
                showInLegend: false,
                data: [[0, 0], [4, 4]]
            }]);
        }
    }, [data]);
    let timeout;
    const resizeObserver = new ResizeObserver(entries => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        setOptions(handleOptions())
      }, 100);
    });
    useEffect(() => {
        resizeObserver.observe(chartRef.current);
        return () => {
            resizeObserver.disconnect();
        };
    }, [size, series])

    return (
        <div ref={chartRef} style={{ display: "flex", width: '100%', height: '100%' }}>
            {data?.length > 0 && <HighchartsReact highcharts={Highcharts} options={options} />}
        </ div >
    );
};
