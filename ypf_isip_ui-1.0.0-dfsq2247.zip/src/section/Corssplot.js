import HighchartsReact from "highcharts-react-official";
import Highcharts from 'highcharts';
import { useEffect, useRef, useState } from 'react';

export default function Crossplot({ data }) {
    const [size, setSize] = useState(undefined)
    const [options, setOptions] = useState(undefined)
    const [series, setSeries] = useState([])
    const chartRef = useRef(null);
    const data1 = [
        { x: 1 / 10, y: 1.5 / 10 },
        { x: 2 / 10, y: 3 / 10 },
        { x: 4 / 10, y: 1.8 / 10 },
        { x: 5 / 10, y: 3.2 / 10 },
        { x: 6 / 10, y: 2 / 10 }
    ];
    const data2 = data1.map(item => ({
        x: item.y,
        y: item.x
    }));

    const maxDataX = 1;
    const maxDataY = 1;
    const max = 1;
    const handleOptions = () => ({
        chart: {
            type: 'scatter',
            backgroundColor: 'var(--palette-background-b-4)',
            plotBackgroundColor: 'var(--palette-background-b-3)',
            style: {
                aspectRatio: '1 / 1'
            },
            ...size,
            events: {
                load: function () {
                    const chart = this;

                    const plotWidth = chart.plotWidth;
                    const plotHeight = chart.plotHeight;

                    const size = Math.min(plotWidth, plotHeight);

                    chart.setSize(size + chart.plotLeft * 2, size + chart.plotTop * 2, false);
                }
            }
        },
        xAxis: {
            title: {
                text: 'ISIP POST (psi/tdv)',
                style: { color: 'var(--palette-primary-text-7)' }
            },
            gridLineWidth: 1,
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: { style: { color: 'var(--palette-primary-text-7)' } },
            tickLength: 0,
            min: 0,
            max: max,
            tickInterval: max / 5,
            gridLineWidth: 1,
        },
        yAxis: {
            title: {
                text: 'ISIP PRE (psi/tdv)',
                style: {
                    color: 'var(--palette-primary-text-7)',
                },
            },
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: {
                style: {
                    color: 'var(--palette-primary-text-7)',
                },
            },
            gridLines: true,
            min: 0,
            max: max,
            tickInterval: max / 5,
            gridLineWidth: 1,
        },
        legend: {
            itemStyle: {
                color: 'var(--palette-primary-text-7)',
            },
        },
        plotOptions: {
            scatter: {
                tooltip: {
                    pointFormat: 'X: {point.x}, Y: {point.y}',
                },
            },
        },
        series: series,
        credits: {
            enabled: false
        }
    }
    );

    const scale = 0.9

    useEffect(() => {
        if (!chartRef.current) {
            return;
        }

        const resizeObserver = new ResizeObserver((entries) => {
            for (let entry of entries) {
                if (entry.contentRect.width > entry.contentRect.height) {
                    setSize({
                        width: Math.floor(entry.contentRect.height * scale),
                        height: Math.floor(entry.contentRect.height * scale)
                    });
                } else {
                    setSize({
                        width: Math.floor(entry.contentRect.width * scale),
                        height: Math.floor(entry.contentRect.width * scale)
                    });
                }
            }
        });

        resizeObserver.observe(chartRef.current);

        return () => {
            resizeObserver.disconnect();
        };
    }, []);

    const serieMock = [
        {
          symbol: 'square',
          radius: 4,
          fillColor: '#6464FF80',
          lineColor: '#6464FF',
          lineWidth: 1,
        },
        {
          symbol: 'triangle',
          radius: 4,
          fillColor: '#FFCC0080',
          lineColor: '#FFCC00',
          lineWidth: 1,
        },
        {
          symbol: 'circle',
          radius: 4,
          fillColor: '#00CC6680',
          lineColor: '#00CC66',
          lineWidth: 1,
        },
        {
          symbol: 'diamond',
          radius: 4,
          fillColor: '#FF668080',
          lineColor: '#FF6680',
          lineWidth: 1,
        },
      ];
    useEffect(() => {
        if (data.length > 1) {
            const seriesBuild = data.map((serie, key) => {
                const serieData = Object.keys(serie.stages).map((stg) => {
                    const d = serie.stages[stg]
                    const y = d.isip_post / d.tvd
                    const x = d.isip_pre / d.tvd
                    return { x, y }
                })
                return {
                    name: serie.well,
                    data: serieData,
                    marker: serieMock[key],
                }
            })
            setSeries(seriesBuild)
        }

    }, [data])

    useEffect(() => {
        setOptions(handleOptions())
    }, [size, series])
    return (
        <div ref={chartRef} style={{ display: "flex", width: '100%', height: '100%' }}>
            <HighchartsReact highcharts={Highcharts} options={options} />
        </ div >
    );
};
