import { AssetsMultipleSelector, MenuItem, Select, StyledDropdownEditor } from '@corva/ui/components';
import { TextInput } from '@corva/ui/componentsV2';
import { useEffect, useState } from 'react';
import styles from './FilterBar.css'
export default function FilterBar({ setConfig, config, stages, cpDataFiltered, setSource, source }) {
    const [stageList, setStageList] = useState([])
    const handleConfig = ({ param, value }) => {
        let auxChange = {}
        if (param == "stageMode" && value == "all") {
            auxChange = { stages: [] }
        }
        setConfig(prev => ({ ...prev, ...auxChange, [param]: value }))
    }
    useEffect(() => {
        if (stages && Object.keys(stages)?.length > 0) {
            let stageListAux = []
            Object.keys(stages).map((param) => {
                if (stages[param].isip_post != undefined && stages[param].isip_pre != undefined && stages[param].tvd != undefined) {
                    stageListAux.push({ label: `Stage ${stages[param].stage_number}`, value: stages[param].stage_number })
                }
            })
            setStageList(stageListAux)
        }
    }, [stages])
    useEffect(() => {
        if (config?.padSelected?.mode == "pad") {
            handleConfig({ param: "stageMode", value: "all" })
            handleConfig({ param: "stages", value: [] })
        }
    }, [config?.padSelected?.mode])
    return <div className={styles.FilterBar}>

        <Select defaultValue={"Corva"} label="Source" onChange={e => setSource(e.target.value)}>
            <MenuItem value="Corva">Corva</MenuItem>
            <MenuItem value="PJR">PJR</MenuItem>
        </Select>
        <Select defaultValue={"all"} label="Stages" onChange={e => handleConfig({ param: "stageMode", value: e.target.value })}>
            <MenuItem value="all">All Stages</MenuItem>
            {config?.padSelected?.mode != "pad" && cpDataFiltered?.length > 0 && <MenuItem value="manual">Manual Stages</MenuItem>}
        </Select>
        {config?.padSelected?.mode != "pad" && config?.stageMode == "manual" && (
            <StyledDropdownEditor
                currentValue={config?.stages}
                placeholder="Select Stages"
                options={stageList}
                onChange={val => handleConfig({ param: "stages", value: val })}
                multiple={true}
            />
        )}
        <TextInput label="Top perforation" type='number' value={config.top_perforation} onChange={(e) => handleConfig({ param: "top_perforation", value: e })} />
        <TextInput label="Bottom perforation" type='number' value={config.bottom_perforation} onChange={(e) => handleConfig({ param: "bottom_perforation", value: e })} />

    </div>
}