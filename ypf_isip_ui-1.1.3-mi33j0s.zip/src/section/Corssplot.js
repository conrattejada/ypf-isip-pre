import HighchartsReact from "highcharts-react-official";
import Highcharts from 'highcharts';
import { use, useEffect, useRef, useState } from 'react';
import { reverse } from "lodash";
function gerarSeriesAleatorias(min, max, numeroDeSeries, quantidadeDeDados) {
    const series = [];

    for (let i = 0; i < numeroDeSeries; i++) {
        const dados = Array.from({ length: quantidadeDeDados }, () => {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        });
        series.push(dados);
    }
    return series;
}


export default function Crossplot({ data, config, dataFiltered }) {
    const [chartKey, setChartKey] = useState(0);
    const [size, setSize] = useState({
        width: 400,
        height: 400
    })
    const [options, setOptions] = useState(undefined)
    const [series, setSeries] = useState([])
    const max = 4
    const chartRef = useRef(null);

    const handleOptions = (seriesData) => ({
        chart: {
            zoomType: 'xy',
            type: 'scatter',
            backgroundColor: 'var(--palette-background-b-4)',
            plotBackgroundColor: 'var(--palette-background-b-3)',
            width: 500,
            height: 500,
            marginLeft: 50,
            marginRight: 50,
            marginBottom: 100,

            spacingTop: 10,
            spacingRight: 10,
            spacingBottom: 10,
            spacingLeft: 10,
            resetZoomButton: {
                position: {
                    align: 'right',
                    verticalAlign: 'top',
                    x: 0,
                    y: 0
                }
            },
            events: {
                load: function () {
                    const chart = this;
                    drawDiagonal(chart);
                },
                redraw: function () {
                    const chart = this;
                    drawDiagonal(chart);
                },
            },
        },
        xAxis: {
            title: {
                text: 'ISIP PRE (psi/ft)',
                style: { color: 'var(--palette-primary-text-7)' }
            },
            gridLineWidth: 1,
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: { style: { color: 'var(--palette-primary-text-7)' } },
            tickLength: 0,
            min: 0,
            gridLineWidth: 1,
            max: max,
            tickInterval: max / 5,
            gridLineWidth: 1,
        },
        yAxis: {
            title: {
                text: 'ISIP POST (psi/ft)',
                style: {
                    color: 'var(--palette-primary-text-7)',
                },
            },
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: {
                style: {
                    color: 'var(--palette-primary-text-7)',
                },
            },
            gridLines: true,
            min: 0,
            gridLineWidth: 1,
            max: max,
            tickInterval: max / 5,
            gridLineWidth: 1,
        },
        legend: {
            itemStyle: {
                color: 'var(--palette-primary-text-7)',
            },
        },
        plotOptions: {
            scatter: {
                tooltip: {
                    pointFormat: 'X: {point.x}, Y: {point.y}',
                },
            },
        },
        tooltip: {
            formatter: function () {
                // Acessa o valor alternativo no ponto
                return `
                <b>Well: ${this.series.name}</b><br/>
                Stage Number: ${this?.point?.stage_number}<br/>
                x: ${this.x}<br/>
                y: ${this.y}
              `;
            },
        },
        title: { text: null },
        series: seriesData,
        credits: {
            enabled: false
        }
    }
    );


    function drawDiagonal(chart) {
        if (chart.customDiagonal) {
            chart.customDiagonal.destroy();
        }

        const x1 = chart.xAxis[0].toPixels(0);
        const y1 = chart.yAxis[0].toPixels(0);
        const x2 = chart.xAxis[0].toPixels(4);
        const y2 = chart.yAxis[0].toPixels(4);

        const path = ["M", x1, y1, "L", x2, y2];
        chart.customDiagonal = chart.renderer
            .path(path)
            .attr({
                stroke: "red",
                "stroke-width": 2,
                "stroke-dasharray": "5,5",
                zIndex: 0,
            })
            .add();
    }

    const serieMock = [
        {
            symbol: 'square',
            radius: 4,
            fillColor: '#6464FF80',
            lineColor: '#6464FF',
            lineWidth: 1,
        },
        {
            symbol: 'triangle',
            radius: 4,
            fillColor: '#FFCC0080',
            lineColor: '#FFCC00',
            lineWidth: 1,
        },
        {
            symbol: 'circle',
            radius: 4,
            fillColor: '#00CC6680',
            lineColor: '#00CC66',
            lineWidth: 1,
        },
        {
            symbol: 'diamond',
            radius: 4,
            fillColor: '#FF668080',
            lineColor: '#FF6680',
            lineWidth: 1,
        },
        {
            symbol: 'triangle-down',
            radius: 4,
            fillColor: '#FF990080',
            lineColor: '#FF9900',
            lineWidth: 1,
        },
        {
            symbol: 'triangle-left',
            radius: 4,
            fillColor: '#0099FF80',
            lineColor: '#0099FF',
            lineWidth: 1,
        },
        {
            symbol: 'triangle-right',
            radius: 4,
            fillColor: '#9900FF80',
            lineColor: '#9900FF',
            lineWidth: 1,
        },
        {
            symbol: 'rect',
            radius: 4,
            fillColor: '#00CCCC80',
            lineColor: '#00CCCC',
            lineWidth: 1,
        },
    ];


    useEffect(() => {
        if (data?.length > 0) {
            let maxAux = 0;
            const dataToUse = (dataFiltered ? dataFiltered : data) || []
            const seriesBuild = dataToUse?.map((serie, key) => {
                const serieData = Object.keys(serie.stages).map((stg) => {

                    const d = serie.stages[stg];
                    const y = d.isip_post / d.tvd;
                    const x = d.isip_pre / d.tvd;
                    if (!Number.isNaN(x) && !Number.isNaN(y)) {
                        const newValue = Math.max(maxAux, x, y);
                        maxAux = newValue;
                        let ableToShow = true
                        if (config?.top_perforation || config?.bottom_perforation) {
                            ableToShow = (!config.top_perforation || config.top_perforation > d.top_perforation) && (!config.bottom_perforation || (config.bottom_perforation > d.bottom_perforation))
                        }
                        if (ableToShow) {
                            return { x: Number(x?.toFixed(3)), y: Number(y?.toFixed(3)), stage_number: d?.stage_number };
                        } else {
                            return { x: undefined, y: undefined, stage_number: undefined }
                        }
                    } else {
                        return { x: undefined, y: undefined, stage_number: undefined }
                    }
                });

                return {
                    name: serie.well.name,
                    data: serieData.filter((item) => item?.x != undefined && item?.y != undefined && item?.stage_number != undefined),
                    enabled: true,
                    marker: serieMock[key],
                };
            });

            const rest = Math.floor(maxAux) - maxAux
            if (rest + 2 > 5) {
                maxAux = Math.floor(maxAux) + 1
            } else {
                maxAux = Math.floor(maxAux) + 0.5
            }

            setSeries([...seriesBuild]);

        }
    }, [data, dataFiltered, config?.top_perforation, config?.bottom_perforation]);

    useEffect(() => {
        setOptions(handleOptions(series))
    }, [series])

    const chartWidth = 400;
    const chartHeight = 400;
    const barThickness = 100;
    const [dataLaranja, dataRoxa] = gerarSeriesAleatorias(1, 10, 2, 20);
    const rightOptions = {
        chart: {
            type: 'bar',
            height: chartHeight,
            width: barThickness,
            margin: [0, 0, 0, 0],
            spacing: [0, 0, 0, 0],
            backgroundColor: 'var(--palette-background-b-4)',
            plotBackgroundColor: 'var(--palette-background-b-3)',
        },
        title: { text: null },
        xAxis: {
            visible: true,
            labels: { enabled: false },
            tickAmount: 12,
            reverse: true,
            lineWidth: 1,
            gridLineWidth: 1,
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            tickLength: 0,
            min: 0,
            endOnTick: true,
            maxPadding: 0,
        },
        yAxis: {
            visible: true,
            reversed: false,
            startOnTick: false,
            endOnTick: false,
            minPadding: 0,
            maxPadding: 0,
            labels: { enabled: false },
            lineWidth: 1,
            gridLineWidth: 1,
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            tickPositions: [0, 'max'],

        },
        legend: { enabled: false },
        tooltip: {
            formatter: function () {
                // Acessa o valor alternativo no ponto
                return `
                x: ${this.x}<br/>
                y: ${this.y}
              `;
            },
        },
        credits: { enabled: false },
        series: [
            {
                data: dataRoxa,
                color: '#800080',
                borderWidth: 0
            },
            {
                data: dataLaranja,
                color: '#FFA500',
                borderWidth: 0
            }
        ],
        plotOptions: {
            series: {
                grouping: true,
                groupPadding: 0,
                pointPadding: 0.1,
                borderWidth: 0,
                animation: false,
                states: {
                    inactive: { enabled: false },
                    hover: { enabled: false }
                }
            }
        }
    };


    const topOptions = {
        chart: {
            type: 'column',
            height: barThickness,
            width: chartWidth,
            margin: [0, 0, 0, 0],
            spacing: [0, 0, 0, 0],
            backgroundColor: 'var(--palette-background-b-4)',
            plotBackgroundColor: 'var(--palette-background-b-3)',
        },
        title: { text: null },
        xAxis: {
            visible: true,
            labels: { enabled: false },
            lineWidth: 1,
            gridLineWidth: 1,
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            tickLength: 0,
            tickAmount: 6,
            min: 0,
            endOnTick: true,
            maxPadding: 0,
        },
        yAxis: {
            visible: true,
            reversed: false,
            labels: { enabled: false },
            lineWidth: 1,
            gridLineWidth: 1,
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            tickPositions: [0, 12],
        },
        legend: { enabled: false },
        tooltip: { enabled: false },
        credits: { enabled: false },
        series: [
            {
                data: dataLaranja.reverse(),
                color: '#FFA500',
                borderWidth: 0
            },
            {
                data: dataRoxa.reverse(),
                color: '#800080',
                borderWidth: 0
            }
        ],
        plotOptions: {
            series: {
                grouping: true,
                groupPadding: 0.1,
                pointPadding: 0.1,
                borderWidth: 0,
                animation: false,
                states: {
                    inactive: { enabled: false },
                    hover: { enabled: false }
                }
            }
        }
    };


    return (
        <div ref={chartRef} style={{ display: 'flex', width: "100%"}}>
            {/*<div style={{ gridRow: 1, gridColumn: 1, marginLeft: "50px" }}>
                <HighchartsReact highcharts={Highcharts} options={topOptions} />
            </div>*/}
            <div style={{ gridRow: 2, gridColumn: 1 }}>
                <HighchartsReact key={chartKey} highcharts={Highcharts} options={options} />
            </div>
            {/*<div style={{ gridRow: 2, gridColumn: 2 }}>
                <HighchartsReact highcharts={Highcharts} options={rightOptions} />
            </div>*/}
        </div>
    );
};
