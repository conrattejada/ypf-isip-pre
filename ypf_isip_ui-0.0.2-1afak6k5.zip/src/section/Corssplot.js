import HighchartsReact from "highcharts-react-official";
import Highcharts from 'highcharts';
import { useEffect, useRef, useState } from 'react';

export default function Crossplot() {
    const [size, setSize] = useState(undefined)
    const [options, setOptions] = useState(undefined)
    const chartRef = useRef(null);
    const data = [
        { x: 1 / 10, y: 1.5 / 10 },
        { x: 2 / 10, y: 3 / 10 },
        { x: 4 / 10, y: 1.8 / 10 },
        { x: 5 / 10, y: 3.2 / 10 },
        { x: 6 / 10, y: 2 / 10 }
    ];
    const data2 = data.map(item => ({
        x: item.y,
        y: item.x
    }));

    const maxDataX = Math.max(...data.map(d => d.x));
    const maxDataY = Math.max(...data.map(d => d.y));
    const max = Math.max(maxDataX, maxDataY);
    const handleOptions = () => ({
        chart: {
            type: 'scatter',
            backgroundColor: 'var(--palette-background-b-4)',
            plotBackgroundColor: 'var(--palette-background-b-3)',
            style: {
                aspectRatio: '1 / 1'
            },
            ...size,
            events: {
                load: function () {
                    const chart = this;

                    const plotWidth = chart.plotWidth;
                    const plotHeight = chart.plotHeight;

                    const size = Math.min(plotWidth, plotHeight);

                    chart.setSize(size + chart.plotLeft * 2, size + chart.plotTop * 2, false);
                }
            }
        },
        xAxis: {
            title: {
                text: 'ISIP POST (psi/tdv)',
                style: { color: 'var(--palette-primary-text-7)' }
            },
            gridLineWidth: 1,
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: { style: { color: 'var(--palette-primary-text-7)' } },
            tickLength: 0,
            min: 0,
            max: max,
            tickInterval: max / 5,
            gridLineWidth: 1,
        },
        yAxis: {
            title: {
                text: 'ISIP PRE (psi/tdv)',
                style: {
                    color: 'var(--palette-primary-text-7)',
                },
            },
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: {
                style: {
                    color: 'var(--palette-primary-text-7)',
                },
            },
            gridLines: true,
            min: 0,
            max: max,
            tickInterval: max / 5,
            gridLineWidth: 1,
        },
        legend: {
            itemStyle: {
                color: 'var(--palette-primary-text-7)',
            },
        },
        plotOptions: {
            scatter: {
                tooltip: {
                    pointFormat: 'X: {point.x}, Y: {point.y}',
                },
            },
        },
        series: [
            {
                name: 'ISIP PRE',
                data: data,
                marker: {
                    symbol: 'square',
                    radius: 4,
                    fillColor: '#6464FF80',
                    lineColor: '#6464FF',
                    lineWidth: 1,
                },
            },
            {
                name: 'ISIP POST',
                data: data2,
                marker: {
                    symbol: 'triangle',
                    radius: 4,
                    fillColor: '#FFCC0080',
                    lineColor: '#FFCC00',
                    lineWidth: 1,
                },
            },
            {
                name: '45º',
                type: 'line',
                color: 'red',
                dashStyle: 'Dash',
                marker: { enabled: false },
                enableMouseTracking: false,
                data: [
                    [0, 0],
                    [max, max] // ponto final pra linha
                ],
                showInLegend: false
            }
        ],
        credits: {
            enabled: false
        }
    }
    );

    const scale = 0.9

    useEffect(() => {
        if (!chartRef.current) {
            return;
        }

        const resizeObserver = new ResizeObserver((entries) => {
            for (let entry of entries) {
                if (entry.contentRect.width > entry.contentRect.height) {
                    setSize({
                        width: Math.floor(entry.contentRect.height * scale),
                        height: Math.floor(entry.contentRect.height * scale)
                    });
                } else {
                    setSize({
                        width: Math.floor(entry.contentRect.width * scale),
                        height: Math.floor(entry.contentRect.width * scale)
                    });
                }
            }
        });

        resizeObserver.observe(chartRef.current);

        return () => {
            resizeObserver.disconnect();
        };
    }, []);

    useEffect(() => {
        setOptions(handleOptions())
    }, [size])
    console.log(options)
    return (
        <div ref={chartRef} style={{ display: "flex", width: '100%', height: '100%' }}>
            <HighchartsReact highcharts={Highcharts} options={options} />
        </ div >
    );
};
