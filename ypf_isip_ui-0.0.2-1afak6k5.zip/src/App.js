import { AppContainer, AppHeader } from '@corva/ui/componentsV2';
import { useAppCommons } from '@corva/ui/effects';

import { DEFAULT_SETTINGS } from './constants';
import logo from './assets/logo.svg';

import styles from './App.css';
import Crossplot from './section/Corssplot';

/**
 * @param {Object} props
 * @param {boolean} props.isExampleCheckboxChecked
 * @param {Object} props.fracFleet
 * @param {Object} props.well
 * @param {Object[]} props.wells
 * @returns
 */
function App({
  isExampleCheckboxChecked = DEFAULT_SETTINGS.isExampleCheckboxChecked,
  fracFleet,
  well,
  wells,
}) {
  const { appKey } = useAppCommons();
  // NOTE: On general type dashboard app receives wells array
  // on asset type dashboard app receives well object
  const wellsList = wells || [well];

  return (
    <AppContainer header={<AppHeader />} testId={appKey}>
      <div className={styles.container}>
        <Crossplot />
      </div>
    </AppContainer>
  );
}

// Important: Do not change root component default export (App.js). Use it as container
//  for your App. It's required to make build and zip scripts work as expected;
export default App;
