import HighchartsReact from "highcharts-react-official";
import Highcharts from 'highcharts';
import { useEffect, useRef, useState, useLayoutEffect } from 'react';
import styles from './Crossplot.css';

function useContainerSize(ref) {
    const [size, setSize] = useState({ width: 400, height: 400 });

    useLayoutEffect(() => {
        if (!ref.current) return;
        const observer = new ResizeObserver(([entry]) => {
            const { width, height } = entry.contentRect;
            setSize({ width, height });
        });
        observer.observe(ref.current);
        return () => observer.disconnect();
    }, [ref]);

    return size;
}

export default function Crossplot({ data, config, dataFiltered }) {
    const containerRef = useRef(null);
    const { width, height } = useContainerSize(containerRef);
    const [options, setOptions] = useState();
    const [series, setSeries] = useState([]);

    const MAX_AXIS = 4;

    const serieMock = [
        { symbol: 'square', radius: 4, fillColor: '#6464FF80', lineColor: '#6464FF', lineWidth: 1 },
        { symbol: 'triangle', radius: 4, fillColor: '#FFCC0080', lineColor: '#FFCC00', lineWidth: 1 },
        { symbol: 'circle', radius: 4, fillColor: '#00CC6680', lineColor: '#00CC66', lineWidth: 1 },
        { symbol: 'diamond', radius: 4, fillColor: '#FF668080', lineColor: '#FF6680', lineWidth: 1 },
        { symbol: 'triangle-down', radius: 4, fillColor: '#FF990080', lineColor: '#FF9900', lineWidth: 1 },
        { symbol: 'triangle-left', radius: 4, fillColor: '#0099FF80', lineColor: '#0099FF', lineWidth: 1 },
        { symbol: 'triangle-right', radius: 4, fillColor: '#9900FF80', lineColor: '#9900FF', lineWidth: 1 },
        { symbol: 'rect', radius: 4, fillColor: '#00CCCC80', lineColor: '#00CCCC', lineWidth: 1 },
    ];

    function drawDiagonal(chart) {
        if (chart.customDiagonal) chart.customDiagonal.destroy();
        const x1 = chart.xAxis[0].toPixels(0);
        const y1 = chart.yAxis[0].toPixels(0);
        const x2 = chart.xAxis[0].toPixels(MAX_AXIS);
        const y2 = chart.yAxis[0].toPixels(MAX_AXIS);
        const path = ["M", x1, y1, "L", x2, y2];
        chart.customDiagonal = chart.renderer
            .path(path)
            .attr({
                stroke: "red",
                "stroke-width": 2,
                "stroke-dasharray": "5,5",
                zIndex: 0,
            })
            .add();
    }

    const handleOptions = (seriesData) => ({
        chart: {
            zoomType: 'xy',
            type: 'scatter',
            width,
            height,
            backgroundColor: 'var(--palette-background-b-4)',
            plotBackgroundColor: 'var(--palette-background-b-3)',
            marginLeft: 70,
            marginRight: 50,
            marginBottom: 100,
            spacing: [10, 10, 10, 10],
            resetZoomButton: {
                position: { align: 'right', verticalAlign: 'top', x: 0, y: 0 }
            },
            events: {
                load: function () { drawDiagonal(this); },
                redraw: function () { drawDiagonal(this); }
            }
        },
        xAxis: {
            title: {
                text: 'ISIP PRE (psi/ft)',
                style: { color: 'var(--palette-primary-text-7)' }
            },
            min: 0,
            max: MAX_AXIS,
            tickInterval: MAX_AXIS / 5,
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: { style: { color: 'var(--palette-primary-text-7)' } },
            tickLength: 0,
            gridLineWidth: 1
        },
        yAxis: {
            title: {
                text: 'ISIP POST (psi/ft)',
                style: { color: 'var(--palette-primary-text-7)' }
            },
            min: 0,
            max: MAX_AXIS,
            tickInterval: MAX_AXIS / 5,
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: { style: { color: 'var(--palette-primary-text-7)' } },
            gridLineWidth: 1
        },
        legend: {
            itemStyle: { color: 'var(--palette-primary-text-7)' }
        },
        tooltip: {
            formatter: function () {
                return `
                    <b>Well: ${this.series.name}</b><br/>
                    Stage Number: ${this?.point?.stage_number}<br/>
                    ISIP POST (psi/ft): ${this.x}<br/>
                    ISIP PRE (psi/ft): ${this.y}
                `;
            }
        },
        plotOptions: {
            scatter: {
                tooltip: {
                    pointFormat: 'ISIP POST (psi/ft): {point.x}, ISIP PRE (psi/ft): {point.y}'
                }
            }
        },
        title: { text: null },
        series: seriesData,
        credits: { enabled: false }
    });

    useEffect(() => {
        if (!data?.length) return;
        const dataToUse = dataFiltered ?? data;

        const seriesBuild = dataToUse.map((serie, key) => {
            const serieData = Object.keys(serie.stages).map((stg) => {
                const d = serie.stages[stg];
                const y = d.isip_post / d.tvd;
                const x = d.isip_pre / d.tvd;

                if (Number.isNaN(x) || Number.isNaN(y)) return null;

                const show = (!config?.top_perforation || (config.top_perforation*3.28084) < d.top_perforation) &&
                             (!config?.bottom_perforation || (config.bottom_perforation*3.28084) > d.bottom_perforation);

                return show
                    ? { x: +x.toFixed(3), y: +y.toFixed(3), stage_number: d?.stage_number }
                    : null;
            }).filter(Boolean);

            return {
                name: serie.well.name,
                data: serieData,
                enabled: true,
                marker: serieMock[key]
            };
        });

        setSeries(seriesBuild);
    }, [data, dataFiltered, config?.top_perforation, config?.bottom_perforation]);

    useEffect(() => {
        if (width > 0 && height > 0 && series.length > 0) {
            setOptions(handleOptions(series));
        }
    }, [width, height, series]);
    console.log(series)
    return (
        <div ref={containerRef} className={styles.Crossplot}>
            {options && <HighchartsReact highcharts={Highcharts} options={options} />}
        </div>
    );
}
