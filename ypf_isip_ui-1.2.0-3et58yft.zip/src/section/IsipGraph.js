// ChartComponent.tsx
import Highcharts, { setOptions } from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import styles from './Crossplot.css'
function useContainerSize(ref) {
    const [size, setSize] = useState({ width: 400, height: 400 });


    useLayoutEffect(() => {
        if (!ref.current) return;
        const observer = new ResizeObserver(([entry]) => {
            const { width, height } = entry.contentRect;
            setSize({ width, height });
        });
        observer.observe(ref.current);
        return () => observer.disconnect();
    }, [ref]);

    return size;
}
export default function IsipGraph({ data, isOpen, well }) {
    const containerRef = useRef(null);
    const { width, height } = useContainerSize(containerRef);

    const defaultOptions = {
        chart: {
            zoomType: 'xy',
            type: 'scatter',
            width: (width - (Number(isOpen) * 50)),
            height,
            backgroundColor: 'var(--palette-background-b-4)',
            plotBackgroundColor: 'var(--palette-background-b-3)',
            marginLeft: 70,
            marginRight: 50,
            marginBottom: 100,
            spacing: [10, 10, 10, 10],
            resetZoomButton: {
                position: { align: 'right', verticalAlign: 'top', x: 0, y: 0 }
            }
        },
        xAxis: {
            title: {
                text: 'Tope <span style="color: #B0B0B0">(m)</span>',
                style: { color: 'var(--palette-primary-text-1)' }, // branco
                useHTML: true
            },
            labels: {
                style: { color: 'var(--palette-primary-text-7)' } // cinza
            },
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: { style: { color: 'var(--palette-primary-text-7)' } },
            tickLength: 0,
            gridLineWidth: 1
        },
        yAxis: {
            title: {        
                text: 'Pressure <span style="color: #B0B0B0">(psi)</span>',
                style: { color: 'var(--palette-primary-text-1)' } // branco
            },
            labels: {
                style: { color: 'var(--palette-primary-text-7)' } // cinza
            },
            gridLineColor: 'var(--palette-background-b-8)',
            lineColor: 'var(--palette-background-b-8)',
            labels: { style: { color: 'var(--palette-primary-text-7)' } },
            gridLineWidth: 1
        },
        legend: {
            itemStyle: { color: 'var(--palette-primary-text-7)' }
        },
        tooltip: {
            formatter: function () {
                return `
                    <b>Well: ${this.series.name}</b><br/>
                    Stage Number: ${this?.point?.stage_number}<br/>
                    Y: ${this.y}<br/>
                    X: ${this.x}
                `;
            }
        },
        plotOptions: {
            scatter: {
                tooltip: {
                    pointFormat: 'ISIP POST (psi/ft): {point.x}, ISIP PRE (psi/ft): {point.y}'
                }
            }
        },
        title: { text: null },
        credits: { enabled: false },

    };

    const [options, setOptions] = useState(defaultOptions)
    
    useEffect(() => {
        const wellData = data?.find((item)=> item.well.id == well?.[0]?.toString()) || undefined
        if (wellData) {
            let postData = []
            let preData = []
            let promedioData = []
            Object.values(wellData?.stages)?.map(({ isip_pre, isip_post, tvd, top_perforation, stage_number }) => {
                if (isip_pre != undefined && isip_post != undefined && tvd != undefined && top_perforation != undefined) {
                    const top_perforation_m = top_perforation/3.28084
                    postData.push({ y: isip_post, x: top_perforation_m, stage_number })
                    preData.push({ y: isip_pre, x: top_perforation_m, stage_number })
                    promedioData.push({ y: isip_post - isip_pre, x: top_perforation_m, stage_number })
                }
            })
            const series = [
                {
                    type: 'column', // ou 'bar' se quiser horizontal
                    name: 'Pomedio de Presion neta',
                    data: promedioData,
                    color: '#8796C8',
                },
                {
                    type: 'line',
                    name: 'Pomedio de ISIP PostFrac',
                    data: postData,
                    color: '#007bff',
                },
                {
                    type: 'line',
                    name: 'Pomedio de ISIP PreFrac',
                    data: preData,
                    color: '#28a745',
                },
            ]
            setOptions({ ...defaultOptions, series })
        }
    }, [data, isOpen, width, height, isOpen, well])


    return (
        <div ref={containerRef} className={styles.Crossplot}>
           {well ? <HighchartsReact highcharts={Highcharts} options={options} /> : "Select a Well" } 
        </div>)
}
